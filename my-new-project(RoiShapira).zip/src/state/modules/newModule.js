
export const state = {
  myNewModule: "Here is my new state"
}

export const mutations = {

}

export const getters = {

}

export const actions = {
 
}

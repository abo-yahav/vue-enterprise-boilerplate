import Loading from './_loading.vue'

describe('@views/loading', () => {
  it('is a valid view', () => {
    expect(Loading).toBeAViewComponent()
  })
})

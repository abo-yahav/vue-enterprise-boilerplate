module.exports = {
  plugins: ['cypress'],
  env: {
    'cypress/globals': true,
  },
}
